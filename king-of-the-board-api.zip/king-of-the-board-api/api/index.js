// Vercel serverless entry point. Vercel's Node runtime can invoke an Express
// app directly since it is a valid (req, res) request handler.
const app = require('../src/app');

module.exports = app;
