/* Quick end-to-end smoke test against a running local server.
 * Usage: BASE_URL=http://localhost:3000 npm run smoke-test
 */
const BASE_URL = process.env.BASE_URL || 'http://localhost:3000';

async function req(method, path, body) {
  const res = await fetch(`${BASE_URL}${path}`, {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  return { status: res.status, data };
}

function assert(cond, msg) {
  if (!cond) throw new Error(`FAILED: ${msg}`);
  console.log(`OK: ${msg}`);
}

(async () => {
  let r = await req('GET', '/api/game/current');
  assert(r.status === 200, 'GET /api/game/current -> 200');
  assert(r.data.game.stats.totalPieces === 32, 'game has 32 pieces');

  r = await req('GET', '/api/pieces');
  assert(r.status === 200 && r.data.count === 32, 'GET /api/pieces returns 32 pieces');

  const king = r.data.pieces.find((p) => p.id === 'white-king');
  assert(!!king, 'white-king exists in piece list');

  r = await req('POST', '/api/pieces/white-king/bid', {
    amount: king.currentPrice + 5,
    company: { name: 'Acme Corp', website: 'https://acme.example.com', contact: 'hi@acme.example.com' },
  });
  assert(r.status === 201, `POST bid on white-king -> 201 (got ${r.status}: ${JSON.stringify(r.data)})`);

  r = await req('POST', '/api/pieces/white-king/bid', { amount: king.currentPrice + 1, companyId: 'nope' });
  assert(r.status === 400, 'bid below increment is rejected');

  r = await req('GET', '/api/leaderboard');
  assert(r.status === 200 && r.data.leaderboard.length >= 1, 'GET /api/leaderboard has entries');
  assert(r.data.leaderboard[0].id === 'white-king', 'white-king leads the leaderboard');

  r = await req('GET', '/api/activity');
  assert(r.status === 200 && r.data.activity.length >= 1, 'GET /api/activity has entries');

  r = await req('GET', '/api/game/current');
  assert(r.data.game.theKing.piece.id === 'white-king', 'theKing resolves to white-king');

  r = await req('POST', '/api/payment', { pieceId: 'white-king', companyId: r.data.game.theKing.owner.id, amount: 999999 });
  assert(r.status === 400, 'payment amount mismatch is rejected');

  console.log('\nAll smoke tests passed.');
})().catch((err) => {
  console.error(err.message);
  process.exit(1);
});
